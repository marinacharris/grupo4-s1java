package reto4.view;

import java.util.List;
import reto4.controller.ReportesController;
import reto4.model.vo.*;
import javax.swing.*;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.table.DefaultTableModel;


import java.awt.*;

public class ReportesView extends JFrame implements ActionListener{
        private ReportesController controller;
        private JMenuBar menuBar;
        private JMenu menu;
        private JMenuItem primerInf, segundoInf, tercerInf;
        private JTable tabla;
        private DefaultTableModel modelo;
        private JLabel lblTitulo, lblConsulta;


        public ReportesView(){
            controller = new ReportesController();
            menu();
            etiqueta1();
            etiqueta2();
            tabla();
        }
        public void menu(){
            menuBar = new JMenuBar();   
            setJMenuBar(menuBar);
            menu = new JMenu("Informes");
            menuBar.add(menu);
            primerInf = new JMenuItem("Primer informe");
            segundoInf = new JMenuItem("Segundo informe");
            tercerInf = new JMenuItem("Tercer informe");
            menu.add(primerInf);
            menu.add(segundoInf);
            menu.add(tercerInf);
            primerInf.addActionListener(this);
            segundoInf.addActionListener(this);
            tercerInf.addActionListener(this);
        }
        public void etiqueta1(){
            lblTitulo = new JLabel("Informe Reto 5");
            lblTitulo.setPreferredSize(new Dimension(500, 30));
            lblTitulo.setFont(new Font("Arial", Font.BOLD, 20));
            add(lblTitulo);
        }
        public void etiqueta2(){
            lblConsulta = new JLabel();
            lblConsulta.setPreferredSize(new Dimension(500, 30)); 
            lblConsulta.setFont(new Font("Arial", Font.BOLD, 14));
            add(lblConsulta);
        }
        public void tabla(){
            tabla = new JTable(modelo);
            tabla.setPreferredScrollableViewportSize(new Dimension(500,200));
            add(tabla);
            JScrollPane pane = new JScrollPane(tabla);
            add(pane);
        }





       
       
        public void proyectosFinanciadosPorBanco(String banco) {
            try{
                    List<ProyectoBancoVo> proyectos = controller.listarProyectosPorBanco(banco);
                    for (ProyectoBancoVo i: proyectos){
                        System.out.println(i);
                    }
                }
                catch(Exception e){
                    System.out.println("Error: " + e.getMessage());
                }
                       
        }
        public void totalAdeudadoPorProyectosSuperioresALimite(Double limiteInferior) {
                try{
                    List<DeudasPorProyectoVo> deudas = controller.listarTotalAdeudadoProyectos(limiteInferior);
                    for (DeudasPorProyectoVo i: deudas){
                        System.out.println(i);
                    }
                }
                catch(Exception e){
                    System.out.println("Error: " + e.getMessage());
                }
    
        }
        public void lideres() {
            try{
                List<ListarLideresVo> lideres = controller.listarLideres();
                //Crear Modelo
                modelo = new DefaultTableModel();
                modelo.addColumn("Id Lider");
                modelo.addColumn("Nombre");
                modelo.addColumn("Apellido");
                modelo.addColumn("Ciudad");
                for (ListarLideresVo i: lideres){
                    Object[] fila = new Object[4];
                    fila[0] = i.getId();
                    fila[1] = i.getNombre();
                    fila[2] = i.getApellido();
                    fila[3] = i.getCiudad();
                    modelo.addRow(fila);
                }
                tabla.setModel(modelo);
                modelo.fireTableDataChanged();
            }
            catch(Exception e){
                System.out.println("Error: " + e.getMessage());
            }
        }
        @Override
        public void actionPerformed(ActionEvent e) {
            if (e.getSource() == primerInf){
                lideres();
                lblConsulta.setText("Consulta de líderes");
            }
            
        }
        
}

