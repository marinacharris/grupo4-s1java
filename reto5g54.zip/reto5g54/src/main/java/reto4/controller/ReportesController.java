package reto4.controller;

import java.sql.SQLException;

import reto4.model.dao.ListaLideresDao;
import reto4.model.dao.DeudasPorProyectoDao;
import reto4.model.dao.ProyectosDao;
import reto4.model.vo.*;
import java.util.List;


public class ReportesController {
    private ProyectosDao proyectosDao;
    private DeudasPorProyectoDao deudasPorProyectoDao;
    private ListaLideresDao listaLideresDao;

    public ReportesController(){
        proyectosDao = new ProyectosDao();
        deudasPorProyectoDao = new DeudasPorProyectoDao();
        listaLideresDao = new ListaLideresDao();
    }
    public List<ProyectosVo> listarProyectos() throws SQLException{
        return proyectosDao.listar();
    }
    public List<DeudasPorProyectoVo> listarTotalAdeudadoProyectos() throws SQLException{
        return deudasPorProyectoDao.listar();
    }

    public List<ListaLideresVo> listarLideres() throws SQLException{
        return listaLideresDao.listar();
    }
}

