public class Autenticar {
    public static boolean validar(String usuario, String  clave){
        if(usuario.equals("marinach") && clave.equals("m2022$")){
            return true;
        }
        return false;
    }
}
