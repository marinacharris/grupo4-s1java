import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
public class App extends JFrame implements ActionListener{
    private JLabel lblUsuario,lblClave;
    private JTextField txtUsuario;
    private JButton btnLogin;
    private JPasswordField txtClave;


    public App(){
        setLayout(null);
        lblUsuario = new JLabel("Usuario");
        lblUsuario.setBounds(30,10,100,30);
        add(lblUsuario);
        lblClave = new JLabel("Clave");
        lblClave.setBounds(30,40,100,30);
        add(lblClave);
        txtUsuario = new JTextField();
        txtUsuario.setBounds(150,10,120,25);
        add(txtUsuario);
        txtClave = new JPasswordField();
        txtClave.setBounds(150,40,120,25);
        add(txtClave);
        btnLogin = new JButton("Login");
        btnLogin.setBounds(120,90, 100,30);
        btnLogin.addActionListener(this);
        add(btnLogin);

    }

    public static void main(String[] args) throws Exception {
        App ventana = new App();
        ventana.setSize(350,180);
        ventana.setLocationRelativeTo(null);//ubica la ventana en el centro de la pantalla
        //ventana.setBounds(50,50,350,180);
        ventana.setVisible(true);
        ventana.setTitle("Login");
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==btnLogin){
            String usuario = txtUsuario.getText();
            String clave = new String(txtClave.getPassword());
            if (Autenticar.validar(usuario, clave)){
                JOptionPane.showMessageDialog(App.this,"Login Exitoso", "Login",JOptionPane.INFORMATION_MESSAGE);
            }else{
                JOptionPane.showMessageDialog(null,"Verifique usuario y/o clave", "Login",JOptionPane.ERROR_MESSAGE);
            }


        }
        
    }
}
