import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class App extends JFrame implements ActionListener{
    private JMenuBar mMenuBar;
    private JMenu menu1, menu2, menu3;
    private JMenuItem i1,i2,i3,i4;
    
    public App(){
        setLayout(null);
        mMenuBar = new JMenuBar();
        setJMenuBar(mMenuBar);
        menu1 = new JMenu("Opciones");
        mMenuBar.add(menu1);
        menu2 = new JMenu("Tamaño");
        menu1.add(menu2);
        menu3 = new JMenu("Color");
        menu1.add(menu3);
        i1 = new JMenuItem("640*480");
        menu2.add(i1);
        i2 = new JMenuItem("1024*700");
        menu2.add(i2);
        i3 = new JMenuItem("Azul");
        menu3.add(i3);
        i4 = new JMenuItem("Rojo"); 
        menu3.add(i4);
        i1.addActionListener(this);
        i2.addActionListener(this);
        i3.addActionListener(this);
        i4.addActionListener(this);

    }

    public static void main(String[] args) throws Exception {
        App ventana = new App();
        ventana.setSize(300, 200);
        ventana.setLocationRelativeTo(null);
        ventana.setVisible(true);
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==i1){
            setSize(640,480);
            setLocationRelativeTo(null);
        }
        if(e.getSource()==i2){
            setSize(1024,700);
            setLocationRelativeTo(null);
        }
        if(e.getSource()==i3){
            getContentPane().setBackground(Color.decode("#21B6A8"));
        }
        if(e.getSource()==i4){
            getContentPane().setBackground(new Color(255,0,0));
        }
        
    }
}
