package reto4;

import reto4.view.ReportesView;

public class App 
{
    public static void main( String[] args )
    {
        var reportesView = new ReportesView();
        var banco = "Conavi";
        reportesView.proyectosFinanciadosPorBanco(banco);
    }
}
