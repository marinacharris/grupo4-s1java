package reto4.controller;

import java.sql.SQLException;
import java.util.List;
import reto4.model.dao.*;
import reto4.model.vo.*;

public class ReportesController {
    private ProyectoBancoDao proyectoBancoDao;
    private ComprasDeLiderDao comprasDeLiderDao;
    private DeudasPorProyectoDao deudasPorProyectoDao;

    public ReportesController(){
        proyectoBancoDao = new ProyectoBancoDao();
        comprasDeLiderDao = new ComprasDeLiderDao();
        deudasPorProyectoDao = new DeudasPorProyectoDao();
    }

    public List<ProyectoBancoVo> listarProyectosPorBanco(String banco) throws SQLException{
        return proyectoBancoDao.listar(banco);        
    }

    public List<ComprasDeLiderVo> listarLideresQueMasGastan() throws SQLException{
        return comprasDeLiderDao.listar();
    }

    public List<DeudasPorProyectoVo> listarTotalAdeudadoProyectos(Double limite) throws SQLException{
        return deudasPorProyectoDao.listar(limite);
    }

}
