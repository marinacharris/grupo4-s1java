package crudsql;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class App 

{
    static String url = "jdbc:sqlite:C:\\Users\\robot\\Desktop\\hr.db";
    public static void main( String[] args ) throws Exception
    {
      consultaEmpleados();  
      System.out.println();
      consultaEmpleado(101);
      crearRegistro();
      borrarRegion(6);
      actualizarDep();
    }
    public static void consultaEmpleados(){
        try{
            Connection conexion = DriverManager.getConnection(url);
            Double salariot = 5000.0;
            String sql="select * from employees where salary>"+salariot;
            Statement stm = conexion.createStatement();
            ResultSet rs = stm.executeQuery(sql);
            while (rs.next()) {
                int id = rs.getInt(1);
                String nombre = rs.getString(2);
                String apellido = rs.getString("last_name");
                Double salario = rs.getDouble("Salary");
                System.out.println(id+"\t"+nombre+"\t"+apellido+"\t"+salario);
            }
            rs.close();
            stm.close();
            conexion.close();
        }
        catch (Exception e){
            System.out.println("Error: " + e.getMessage());
        }
    }
    //preparedStatement
    public static void consultaEmpleado(int id_empleado) {
        try{
            String sql = "select * from employees where employee_id=?";
            Connection conexion = DriverManager.getConnection(url);
            PreparedStatement stm = conexion.prepareStatement(sql);
            stm.setInt(1, id_empleado);
            ResultSet rs = stm.executeQuery();
            while (rs.next()) {
                int id = rs.getInt(1);
                String nombre = rs.getString(2);
                String apellido = rs.getString("last_name");
                Double salario = rs.getDouble("Salary");
                System.out.println(id+"\t"+nombre+"\t"+apellido+"\t"+salario);
            }
            rs.close();
            stm.close();
            conexion.close();
        }
        catch (Exception e){
            System.out.println("Error: " + e.getMessage());
        }        

    }   
    // insert to, crear
    public static void crearRegistro(){
        String sql ="insert into departments values (?, ?, ?)";
        try(
            Connection conexion = DriverManager.getConnection(url);
            PreparedStatement stm = conexion.prepareStatement(sql);
        ){  
            stm.setInt(1, 15);
            stm.setString(2, "Bienestar");
            stm.setInt(3, 1500);
            int rows = stm.executeUpdate();
            if (rows>0){
                System.out.println("Registro creado");
            }

        }
        catch(Exception e){
            System.out.println("error al crear registro: "+ e.getMessage());
        }        
    }
    //borrar registro
    public static void borrarRegion(int region_id){
        String sql = "delete from regions where region_id = " + region_id;
        try(
            Connection conexion = DriverManager.getConnection(url);
            Statement stm = conexion.createStatement();
        ){
            int rows =stm.executeUpdate(sql);
            if (rows>0){
                System.out.println("Registro borrado");
            }else{
                System.out.println("No se encontró el registro");
            }
        }
        catch(Exception e){
            System.out.println("Error al eliminar: " + e.getMessage());
        }
    }
    //actualizar registro
    public static void actualizarDep() throws SQLException{
        String sql = "update departments set department_name = 'Meradeo' where department_id=2";
        try(
            Connection conexion = DriverManager.getConnection(url);
            Statement stm = conexion.createStatement();
        ){
            int rows = stm.executeUpdate(sql);
            if (rows>0){
                System.out.println("Registro actualizado");
            }

        }
        /*
        catch (Exception e){
            System.out.println("Error al eliminar: " + e.getMessage());
        }*/
    }

}
